package com.energia.tariff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TariffServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
